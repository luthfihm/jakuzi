<div class="jumbotron mashead">
			<div class="container-fluid" style="padding-top:20px;">
				<div class="row-fluid">
					<div class="hero-unit" style="background:#4e69a2; color:#ffffff;" align="center">
						<h2>Signup berhasil dilakukan silakan login</h2><br>
						<?php echo anchor('login', 'Login Here!', array('class' => 'btn-large btn-inverse')); ?>					
					</div>			
				</div>
			</div>
</div>
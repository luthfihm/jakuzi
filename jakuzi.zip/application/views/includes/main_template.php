<?php $this->load->view('includes/main_header',$main_content); ?>
 
<?php $this->load->view($main_content); ?>
 
<?php $this->load->view('includes/main_footer'); ?>
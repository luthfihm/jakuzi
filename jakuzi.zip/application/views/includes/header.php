<!DOCTYPE html>
<html lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="<?php echo base_url('bootstrap/css/bootstrap.css'); ?>" rel="stylesheet">
	<link href="<?php echo base_url('bootstrap/css/bootstrap-responsive.css'); ?>" rel="stylesheet">
	<script src="<?php echo base_url('jquery-2.0.3.min.js'); ?>" type="text/javascript" ></script>
	<title>Jakuzi - Login</title>
</head>
<body style="background:#4e69a2;">
	<div id="wrap" style="height:600px;">
		<div class="navbar navbar-inverse">
			<div class="navbar-inner">
				<div class="container">
					
				</div>
			</div>
		</div>
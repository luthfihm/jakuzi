<?php $this->load->view('includes/header'); ?>
 
<?php $this->load->view($main_content,$invalid_login); ?>
 
<?php $this->load->view('includes/footer'); ?>